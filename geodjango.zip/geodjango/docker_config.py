DEPLOY_SECURE = True
SECRET_KEY = 'oom0o!*5rqpmr_@i&jxj)i&ov4dfd!mmms6t9o#0^+ningsxhm'